import { FETCHING_DATA, FETCHING_DATA_SUCCESS, FETCHING_DATA_FAILURE } from './types';

export function getData() {
    return {
        type: FETCHING_DATA
    }
}
export function getDataSuccess(data) {
    return {
        type: FETCHING_DATA_SUCCESS,
        data
    }
}

export function getDataFailure() {
    return {
        type: FETCHING_DATA_FAILURE
    }
}
export function fetchDataFromAPI(dispatch) {
    return (dispatch) => {
        dispatch(getData())
        fetch('http://api-dot-hola-edu.appspot.com/api?action=getRandomCourses')
            .then(data => data.json())
            .then(json => {
               
                console.log('columns:', json.data)
                console.log('meta:', json.meta.view)
                console.log('json.data.slice(0, 400):', json.data.slice(0, 400))
                const sample = json.data.slice(0, 400)
                dispatch(getDataSuccess(json.data))
            })
             .catch(err => dispatch(getDataFailure(err)))
    }
}