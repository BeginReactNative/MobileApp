import { ADD, SUB } from './types';

export function addNumber() {
    return {
        type: 'ADD',
       
    }
}
export function subNumber() {
    return {
        type: 'SUB',
      
        }
}
