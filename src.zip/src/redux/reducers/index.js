import { combineReducers } from 'redux';
import testReducer from './testReducer';
import dataReducer from './dataReducer';

const rootReducer = combineReducers({
    testReducer,
    dataReducer
});
export default rootReducer;
