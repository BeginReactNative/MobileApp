import React, { Component } from 'react';
import { View, Text } from 'react-native';

class SignIn extends Component {
    render() {
        return (
            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                <Text> SignIn Screen</Text>
            </View>            
        );
    }
}

export default SignIn;