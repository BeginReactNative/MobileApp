import React, { Component } from 'react';
import { View,Text } from 'react-native';
class GameView extends Component {
    state = {  }
    render() {
        return (
            <View></View>
        );
    }
}

export default GameView;